# @vtk-iam/node

Connect a Node.js backend to VTK IAM:

- `createAccessTokenVerifier`: checks an access token against the IAM's JWKS (signature, issuer, audience, expiry, `token_use`), with key rotation handled by the JWKS cache.
- `requirePermission`, `hasPermissions`, `hasAnyRole`: role and permission checks, with `resource:*` wildcards.
- `@vtk-iam/node/express`: `requireAccessToken`, `requirePermissions`, `requireAnyRole` and `createAuthRouter`, the backend-for-frontend routes (`/api/auth/login`, `/callback`, `/refresh`, `/logout`). With a frontend on its own subdomain of the same site (`frontendBaseUrl`, `additionalAllowedOrigins`), `createCorsMiddleware` answers its credentialed calls and refuses writes from other origins.
- `@vtk-iam/node/fastify` (Fastify 4 and 5): `accessTokenHook`, `permissionsHook`, `anyRoleHook`, `authRoutesPlugin` (the same backend-for-frontend routes as the Express router) and `corsHook` (the same rules as `createCorsMiddleware`). No `@fastify/cookie` needed.
- `@vtk-iam/node/nestjs`: `IamAuthGuard` with `@Permissions()`, `@Roles()` and `@Public()`.
- Sign-in options: `allowedPrompts` (for example `['login']`, so `GET /login?prompt=login` shows the IAM sign-in form for another account) and `signInFailedPath` (a failed sign-in lands on a page of the frontend with `?reason=access_denied` or `?reason=sign_in_failed` instead of JSON).
- Back-channel logout: with an `endedSessions` store given to the routes and to the verifier, the routes gain `POST /backchannel-logout`, where the IAM reports a sign-in session that ended early, and the verifier refuses that session's access tokens at once. `MemoryEndedSessions` serves one process; several processes need a shared `EndedSessionStore`. `createLogoutTokenVerifier` checks a logout token on its own.

How to use it in an application: [docs/INTEGRATION.md](../../docs/INTEGRATION.md). A runnable example: [examples/demo-app](../../examples/demo-app).

## ES modules and CommonJS

The package ships ES modules only. A CommonJS application loads it with `require('@vtk-iam/node')` and `require('@vtk-iam/node/fastify')` (or `/express`, `/nestjs`) on Node.js 22.12 or later: neither the SDK nor its dependencies use top-level await, so no separate CommonJS build is needed. `npm run check:commonjs` requires every entry point of the build from a `.cjs` file and runs in CI. Node.js 22 may print a one-time `ExperimentalWarning`; Node.js 24 does not.

The route answers and the cross-origin rules live in the framework-neutral `BackendForFrontend` and `CrossOriginPolicy` (`src/bff.ts`); the Express and Fastify adapters only translate them, so both behave the same.

## Develop

```bash
npm ci
npm run typecheck
npm test                 # vitest, no network: fake IAM servers run in the test
npm run build            # dist/, what applications import
npm run check:commonjs   # after the build: require() of every entry point from a .cjs file
```

Node.js 22.12 or later. Express, Fastify and NestJS are optional peer dependencies.
